// Recipe admin — create/update recipe with library-only ingredient/utensil pickers
const { useState, useMemo } = React;

// Library catalogs (would come from server) — recipe authors PICK from these
const ING_LIBRARY = [
  { id: "paneer", name: "Paneer", cat: "Dairy", thumb: "matcha", inUse: 18 },
  { id: "tomato", name: "Tomatoes (ripe)", cat: "Vegetable", thumb: "berry", inUse: 64 },
  { id: "onion", name: "Onion", cat: "Vegetable", thumb: "cream", inUse: 121 },
  { id: "cashew", name: "Cashews", cat: "Nut & Seed", thumb: "cream", inUse: 27 },
  { id: "cream", name: "Heavy cream", cat: "Dairy", thumb: "matcha", inUse: 19 },
  { id: "butter", name: "Butter", cat: "Oil & Fat", thumb: "", inUse: 84 },
  { id: "ginger-garlic", name: "Ginger-garlic paste", cat: "Aromatic", thumb: "matcha", inUse: 92 },
  { id: "kasuri-methi", name: "Kasuri methi", cat: "Herb", thumb: "matcha", inUse: 14 },
  { id: "garam-masala", name: "Garam masala", cat: "Spice", thumb: "berry", inUse: 41 },
  { id: "kashmiri-chili", name: "Kashmiri chili powder", cat: "Spice", thumb: "berry", inUse: 33 },
  { id: "cilantro", name: "Cilantro", cat: "Herb", thumb: "matcha", inUse: 58 },
  { id: "salt", name: "Salt", cat: "Seasoning", thumb: "", inUse: 312 }
];

const UT_LIBRARY = [
  { id: "kadhai-cast-iron-9", name: "Cast-iron kadhai", cat: "Cookware", thumb: "cream", inUse: 34 },
  { id: "blender", name: "High-speed blender", cat: "Small appliance", thumb: "", inUse: 67 },
  { id: "fine-strainer", name: "Fine-mesh strainer", cat: "Utensil", thumb: "", inUse: 22 },
  { id: "wooden-spatula", name: "Wooden spatula", cat: "Utensil", thumb: "cream", inUse: 88 },
  { id: "chefs-knife-8", name: "Chef's knife (8\")", cat: "Cutlery", thumb: "", inUse: 145 },
  { id: "cutting-board", name: "Cutting board", cat: "Utensil", thumb: "cream", inUse: 142 },
  { id: "measuring-cups", name: "Measuring cups", cat: "Measuring", thumb: "", inUse: 96 },
  { id: "saucepan", name: "Saucepan (medium)", cat: "Cookware", thumb: "", inUse: 71 }
];

const SAMPLE_RECIPE = {
  id: "paneer-butter-masala",
  name: "Paneer Butter Masala",
  tagline: "creamy · tomato · 35 min",
  cuisine: "North Indian",
  category: "Main",
  difficulty: "Easy",
  servings: 4,
  totalMinutes: 35,
  prepMinutes: 10,
  cookMinutes: 25,
  description: "Restaurant-style silky tomato gravy with cubes of soft paneer.",
  tags: ["vegetarian", "high-protein", "creamy", "weeknight"],
  heroFile: "paneer-overhead-v3.jpg",
  heroSize: "2.4 MB · 1920×1280",
  steps: [
    { title: "Soak the cashews", duration: 5, detail: "Drop cashews in ½ cup hot water. Let them sit while you prep — they need to soften so the gravy stays silky." },
    { title: "Sauté onion + tomato", duration: 10, detail: "Roughly chop onion and tomatoes. In 1 tbsp butter, sauté onion 3 min, then add tomatoes, ginger-garlic paste, and chili. Cook 6–7 min." },
    { title: "Blend the gravy base", duration: 4, detail: "Cool slightly, then blend with soaked cashews and ½ cup water until smooth. Pass through a fine strainer." },
    { title: "Bloom the spices", duration: 2, detail: "Add 2 tbsp butter to the pan. Once melted, add red chili powder, stir 10 seconds. Pour the gravy back in." },
    { title: "Simmer the gravy", duration: 8, detail: "Add salt, sugar, and ¼ cup water if needed. Simmer covered on low. Gravy should glossy up." },
    { title: "Add paneer + finish", duration: 3, detail: "Cube paneer (1-inch). Slip into gravy, add cream, garam masala, crushed kasuri methi. Simmer 2 more minutes." }
  ],
  // ingredients now reference library by id; only `amt`/`unit` is recipe-specific
  ingredients: [
    { ingId: "paneer", amt: "300", unit: "g" },
    { ingId: "tomato", amt: "5", unit: "medium" },
    { ingId: "onion", amt: "1", unit: "large" },
    { ingId: "cashew", amt: "15", unit: "whole" },
    { ingId: "cream", amt: "3", unit: "tbsp" },
    { ingId: "butter", amt: "3", unit: "tbsp" },
    { ingId: "ginger-garlic", amt: "1.5", unit: "tbsp" },
    { ingId: "kasuri-methi", amt: "1", unit: "tsp" },
    { ingId: "garam-masala", amt: "0.5", unit: "tsp" }
  ],
  // utensils reference library by id; only must/nice is recipe-specific
  utensils: [
    { utId: "kadhai-cast-iron-9", must: true },
    { utId: "blender", must: true },
    { utId: "fine-strainer", must: true },
    { utId: "wooden-spatula", must: false }
  ],
  health: [
    "Paneer adds ~14g protein per 100g.",
    "Tomatoes deliver lycopene, more bioavailable when cooked.",
    "Swap cream for cashew paste to cut saturated fat ~40%."
  ]
};

function RecipeAdminApp() {
  const [r, setR] = useState(SAMPLE_RECIPE);
  const [tab, setTab] = useState("basics");
  const [activeStep, setActiveStep] = useState(1);
  const [dirty, setDirty] = useState(true);

  const update = (patch) => { setR(p => ({ ...p, ...patch })); setDirty(true); };
  const updateStep = (i, patch) => update({ steps: r.steps.map((s, k) => k === i ? { ...s, ...patch } : s) });
  const removeStep = (i) => update({ steps: r.steps.filter((_, k) => k !== i) });
  const addStep = () => update({ steps: [...r.steps, { title: "New step", duration: 5, detail: "" }] });

  const updateIng = (i, patch) => update({ ingredients: r.ingredients.map((s, k) => k === i ? { ...s, ...patch } : s) });
  const removeIng = (i) => update({ ingredients: r.ingredients.filter((_, k) => k !== i) });
  const addIngFromLib = (libIng) => {
    if (r.ingredients.some(x => x.ingId === libIng.id)) return;
    update({ ingredients: [...r.ingredients, { ingId: libIng.id, amt: "", unit: "g" }] });
  };

  const updateUt = (i, patch) => update({ utensils: r.utensils.map((s, k) => k === i ? { ...s, ...patch } : s) });
  const removeUt = (i) => update({ utensils: r.utensils.filter((_, k) => k !== i) });
  const addUtFromLib = (libUt) => {
    if (r.utensils.some(x => x.utId === libUt.id)) return;
    update({ utensils: [...r.utensils, { utId: libUt.id, must: true }] });
  };

  return (
    <div className="admin-shell">
      <AdminSidebar active="recipes" />
      <div className="admin-main">
        <AdminTopbar
          crumb={[{ label: "Recipes", href: "#" }, { label: r.name || "Untitled" }]}
          status="draft"
          savedAgo="just now"
        />

        <div className="admin-page">
          <div className="admin-page-head">
            <div>
              <h1>Edit <em>recipe</em></h1>
              <p className="lede">Author the recipe, attach steps. Ingredients & utensils are picked from the library — they always pre-exist.</p>
            </div>
            <div className="admin-page-meta">
              <span><b>id</b> · {r.id}</span>
              <span><b>v.4</b></span>
              <span><b>{r.steps.length}</b> steps</span>
            </div>
          </div>

          <FormTabs
            active={tab}
            onChange={setTab}
            tabs={[
              { id: "basics", label: "Basics" },
              { id: "steps", label: "Steps", badge: r.steps.length },
              { id: "ingredients", label: "Ingredients", badge: r.ingredients.length },
              { id: "utensils", label: "Utensils", badge: r.utensils.length },
              { id: "health", label: "Health" }
            ]}
          />

          <div className="workbench" style={{ marginTop: 20 }}>
            <div className="workbench-form">
              {tab === "basics" && <BasicsTab r={r} update={update} />}
              {tab === "steps" && <StepsTab r={r} updateStep={updateStep} removeStep={removeStep} addStep={addStep} activeStep={activeStep} setActiveStep={setActiveStep} />}
              {tab === "ingredients" && <IngredientsTab r={r} updateIng={updateIng} removeIng={removeIng} addIngFromLib={addIngFromLib} />}
              {tab === "utensils" && <UtensilsTab r={r} updateUt={updateUt} removeUt={removeUt} addUtFromLib={addUtFromLib} />}
              {tab === "health" && <HealthTab r={r} update={update} />}
            </div>

            <div className="workbench-preview">
              <PreviewFrame url={`/recipes/${r.id}`}>
                <RecipePreview r={r} activeStep={activeStep} />
              </PreviewFrame>
              <div style={{ display: "flex", gap: 8, alignItems: "center", padding: "0 4px", fontFamily: "var(--mono)", fontSize: 10, letterSpacing: "0.08em", textTransform: "uppercase", color: "var(--ink-muted)" }}>
                <span>↻ Live preview</span>
                <span>·</span>
                <span>Updates as you type</span>
                <span style={{ marginLeft: "auto", fontFamily: "var(--hand)", textTransform: "none", letterSpacing: 0, fontSize: 18, color: "var(--orange)", transform: "rotate(-3deg)", display: "inline-block" }}>looks tasty!</span>
              </div>
            </div>
          </div>

          <SaveBar dirty={dirty} onDiscard={() => {}} onSaveDraft={() => setDirty(false)} onPublish={() => setDirty(false)} />
        </div>
      </div>
    </div>
  );
}

// ============================================================
// BASICS
// ============================================================
function BasicsTab({ r, update }) {
  return (
    <>
      <FormCard title="Identity" scribble="the headline">
        <div className="field-grid">
          <Field label="Recipe name" required>
            <input className="input serif" value={r.name} onChange={e => update({ name: e.target.value })} />
          </Field>
          <Field label="Tagline" hint="Under 60 chars.">
            <input className="input" value={r.tagline} onChange={e => update({ tagline: e.target.value })} />
          </Field>
          <Field label="Description">
            <textarea className="textarea" value={r.description} onChange={e => update({ description: e.target.value })} />
          </Field>
          <div className="field-grid cols-3">
            <Field label="Cuisine">
              <select className="select" value={r.cuisine} onChange={e => update({ cuisine: e.target.value })}>
                <option>North Indian</option><option>South Indian</option><option>Italian</option><option>Mexican</option><option>Thai</option><option>Japanese</option><option>Mediterranean</option>
              </select>
            </Field>
            <Field label="Category">
              <select className="select" value={r.category} onChange={e => update({ category: e.target.value })}>
                <option>Main</option><option>Side</option><option>Breakfast</option><option>Snack</option><option>Dessert</option>
              </select>
            </Field>
            <Field label="Difficulty">
              <RadioPills value={r.difficulty} options={["Easy", "Medium", "Hard"]} onChange={v => update({ difficulty: v })} />
            </Field>
          </div>
        </div>
      </FormCard>

      <FormCard title="Hero photograph" scribble="the money shot">
        <Field label="Overhead shot" required>
          <Uploader filename={r.heroFile} size={r.heroSize} onClear={() => update({ heroFile: null })} />
        </Field>
      </FormCard>

      <FormCard title="Timing & yield">
        <div className="field-grid cols-4">
          <Field label="Servings"><div className="input-wrap has-suffix"><input className="input mono" value={r.servings} onChange={e => update({ servings: e.target.value })} /><span className="suffix">people</span></div></Field>
          <Field label="Prep"><div className="input-wrap has-suffix"><input className="input mono" value={r.prepMinutes} onChange={e => update({ prepMinutes: e.target.value })} /><span className="suffix">min</span></div></Field>
          <Field label="Cook"><div className="input-wrap has-suffix"><input className="input mono" value={r.cookMinutes} onChange={e => update({ cookMinutes: e.target.value })} /><span className="suffix">min</span></div></Field>
          <Field label="Total" help="auto"><div className="input-wrap has-suffix"><input className="input mono" value={r.totalMinutes} readOnly style={{ color: "var(--ink-muted)" }} /><span className="suffix">min</span></div></Field>
        </div>
      </FormCard>

      <FormCard title="Tags">
        <Field label="Search & recommendation tags" hint="Press enter or comma to add.">
          <ChipInput
            tags={r.tags}
            onAdd={t => update({ tags: [...r.tags, t] })}
            onRemove={i => update({ tags: r.tags.filter((_, k) => k !== i) })}
          />
        </Field>
      </FormCard>
    </>
  );
}

// ============================================================
// STEPS
// ============================================================
function StepsTab({ r, updateStep, removeStep, addStep, activeStep, setActiveStep }) {
  return (
    <FormCard title="Steps" scribble={`${r.steps.length} so far`}>
      <div className="step-list">
        {r.steps.map((s, i) => (
          <div
            key={i}
            className={"step-edit" + (activeStep === i ? " active" : "")}
            onClick={() => setActiveStep(i)}
          >
            <div className="step-edit-head">
              <div className="step-handle">{String(i + 1).padStart(2, "0")}</div>
              <input className="step-edit-title" value={s.title} onChange={e => updateStep(i, { title: e.target.value })} />
              <div className="step-edit-actions">
                <button className="step-icon-btn danger" onClick={() => removeStep(i)}>×</button>
              </div>
            </div>
            <div className="step-edit-body">
              <textarea
                className="step-edit-detail"
                value={s.detail}
                onChange={e => updateStep(i, { detail: e.target.value })}
                placeholder="What does the cook do?"
              />
              <div className="step-edit-side">
                <div className="step-mini">
                  <span className="lbl">Timer</span>
                  <input value={s.duration} onChange={e => updateStep(i, { duration: e.target.value })} />
                  <span style={{ color: "var(--ink-faint)" }}>min</span>
                </div>
              </div>
            </div>
          </div>
        ))}
        <button className="add-step-btn" onClick={addStep}>+ Add step</button>
      </div>
    </FormCard>
  );
}

// ============================================================
// LIBRARY PICKER (shared shape for ingredients + utensils)
// ============================================================
function LibraryPicker({ kind, library, picked, onPick, manageHref, manageLabel }) {
  const [q, setQ] = useState("");
  const isPicked = (id) => picked.some(p => (kind === "ing" ? p.ingId : p.utId) === id);
  const filtered = useMemo(() => {
    const qq = q.toLowerCase().trim();
    return library.filter(x => !qq || x.name.toLowerCase().includes(qq) || x.cat.toLowerCase().includes(qq));
  }, [q, library]);
  return (
    <div className="lib-picker">
      <div className="lib-search">
        <span className="glass">⌕</span>
        <input
          className="lib-search-input"
          placeholder={`Search ${kind === "ing" ? "ingredients" : "utensils"} library…`}
          value={q}
          onChange={e => setQ(e.target.value)}
        />
        <span className="ct">{filtered.length} of {library.length}</span>
      </div>
      <div className="lib-list">
        {filtered.length === 0 ? (
          <div style={{ padding: "32px 20px", textAlign: "center", color: "var(--ink-muted)" }}>
            <div style={{ fontFamily: "var(--serif)", fontStyle: "italic", fontSize: 18, marginBottom: 6 }}>Nothing matches "{q}"</div>
            <div style={{ fontSize: 12 }}>{kind === "ing" ? "Ingredients" : "Utensils"} can only be added from the library. <a href={manageHref} style={{ color: "var(--orange)", textDecoration: "underline" }}>{manageLabel}</a></div>
          </div>
        ) : filtered.map(item => {
          const used = isPicked(item.id);
          return (
            <div key={item.id} className={"lib-row" + (used ? " disabled" : "")} onClick={() => !used && onPick(item)}>
              <div className={"lib-thumb " + (item.thumb || "")} />
              <div>
                <div className="name">{item.name}</div>
                <div className="meta">{item.cat} · used in {item.inUse}</div>
              </div>
              <span /><span />
              {used ? (
                <span className="added">✓ added</span>
              ) : (
                <button className="add-btn">+</button>
              )}
            </div>
          );
        })}
      </div>
      <div className="lib-foot">
        <span>Library only</span>
        <span style={{ color: "var(--ink-faint)" }}>·</span>
        <a href={manageHref}>{manageLabel} →</a>
      </div>
    </div>
  );
}

// ============================================================
// INGREDIENTS — picker + picked rows
// ============================================================
function IngredientsTab({ r, updateIng, removeIng, addIngFromLib }) {
  return (
    <>
      <FormCard title="Picked for this recipe" scribble={`${r.ingredients.length} items`}>
        {r.ingredients.length === 0 ? (
          <div style={{ padding: "20px 16px", textAlign: "center", color: "var(--ink-muted)", fontStyle: "italic", fontFamily: "var(--serif)", fontSize: 16 }}>
            None yet — add ingredients from the library below.
          </div>
        ) : (
          <div className="picked-list">
            {r.ingredients.map((ing, i) => {
              const lib = ING_LIBRARY.find(x => x.id === ing.ingId) || { name: ing.ingId, thumb: "", cat: "—" };
              return (
                <div key={i} className="picked-row">
                  <span className="handle">⋮⋮</span>
                  <div className={"lib-thumb " + (lib.thumb || "")} />
                  <div>
                    <div className="name">{lib.name}</div>
                    <div style={{ fontFamily: "var(--mono)", fontSize: 10, color: "var(--ink-faint)", letterSpacing: "0.08em", textTransform: "uppercase" }}>{lib.cat}</div>
                  </div>
                  <input
                    className="amt-input"
                    value={ing.amt}
                    onChange={e => updateIng(i, { amt: e.target.value })}
                    placeholder="—"
                  />
                  <select
                    style={{ background: "var(--cream-soft)", border: "1px solid var(--rule)", borderRadius: 6, padding: "6px 10px", fontFamily: "var(--mono)", fontSize: 11, color: "var(--ink-soft)", outline: "none" }}
                    value={ing.unit}
                    onChange={e => updateIng(i, { unit: e.target.value })}
                  >
                    <option>g</option><option>kg</option><option>ml</option><option>l</option><option>tsp</option><option>tbsp</option><option>cup</option><option>medium</option><option>large</option><option>whole</option><option>pinch</option>
                  </select>
                  <button className="x" onClick={() => removeIng(i)}>×</button>
                </div>
              );
            })}
          </div>
        )}
      </FormCard>

      <FormCard title="Add from library" scribble="search & pick"
        headRight={<a href="admin-ingredient.html" className="btn-sm ghost" style={{ textDecoration: "none" }}>+ New ingredient ↗</a>}>
        <LibraryPicker
          kind="ing"
          library={ING_LIBRARY}
          picked={r.ingredients}
          onPick={addIngFromLib}
          manageHref="admin-ingredient.html"
          manageLabel="Manage library"
        />
      </FormCard>
    </>
  );
}

// ============================================================
// UTENSILS — picker + picked rows
// ============================================================
function UtensilsTab({ r, updateUt, removeUt, addUtFromLib }) {
  return (
    <>
      <FormCard title="Picked for this recipe" scribble={`${r.utensils.length} items`}>
        {r.utensils.length === 0 ? (
          <div style={{ padding: "20px 16px", textAlign: "center", color: "var(--ink-muted)", fontStyle: "italic", fontFamily: "var(--serif)", fontSize: 16 }}>
            None yet — add utensils from the library below.
          </div>
        ) : (
          <div className="picked-list">
            {r.utensils.map((u, i) => {
              const lib = UT_LIBRARY.find(x => x.id === u.utId) || { name: u.utId, thumb: "", cat: "—" };
              return (
                <div key={i} className="picked-row" style={{ gridTemplateColumns: "auto 36px 1fr auto auto" }}>
                  <span className="handle">⋮⋮</span>
                  <div className={"lib-thumb " + (lib.thumb || "")} />
                  <div>
                    <div className="name">{lib.name}</div>
                    <div style={{ fontFamily: "var(--mono)", fontSize: 10, color: "var(--ink-faint)", letterSpacing: "0.08em", textTransform: "uppercase" }}>{lib.cat}</div>
                  </div>
                  <span
                    className={"ut-tag " + (u.must ? "must" : "nice")}
                    onClick={() => updateUt(i, { must: !u.must })}
                    title="Click to toggle"
                  >
                    {u.must ? "must" : "nice"}
                  </span>
                  <button className="x" onClick={() => removeUt(i)}>×</button>
                </div>
              );
            })}
          </div>
        )}
      </FormCard>

      <FormCard title="Add from library" scribble="search & pick"
        headRight={<a href="admin-utensil.html" className="btn-sm ghost" style={{ textDecoration: "none" }}>+ New utensil ↗</a>}>
        <LibraryPicker
          kind="ut"
          library={UT_LIBRARY}
          picked={r.utensils}
          onPick={addUtFromLib}
          manageHref="admin-utensil.html"
          manageLabel="Manage library"
        />
      </FormCard>
    </>
  );
}

// ============================================================
// HEALTH
// ============================================================
function HealthTab({ r, update }) {
  return (
    <FormCard title="Health facts" scribble="rotates every 3 min">
      <Field label="Talking points" hint="Up to 6 facts. Surfaced one at a time during cooking.">
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          {r.health.map((h, i) => (
            <div key={i} className="row-edit" style={{ gridTemplateColumns: "auto 1fr auto" }}>
              <span className="row-edit-handle">⋮⋮</span>
              <input value={h} onChange={e => {
                const health = [...r.health]; health[i] = e.target.value; update({ health });
              }} />
              <button className="row-edit-x" onClick={() => update({ health: r.health.filter((_, k) => k !== i) })}>×</button>
            </div>
          ))}
          <button className="add-step-btn" onClick={() => update({ health: [...r.health, ""] })}>+ Add fact</button>
        </div>
      </Field>
    </FormCard>
  );
}

// ============================================================
// PREVIEW
// ============================================================
function RecipePreview({ r, activeStep }) {
  const step = r.steps[activeStep] || r.steps[0];
  const firstWord = (r.name || "").split(" ")[0];
  const rest = (r.name || "").split(" ").slice(1).join(" ");
  return (
    <div className="pv-recipe">
      <div className="pv-breadcrumb">
        <span>Home</span><span className="sep">›</span><span>{r.cuisine}</span><span className="sep">›</span><span style={{ color: "var(--ink)" }}>{r.name}</span>
      </div>
      <div>
        <h1 className="pv-title"><em>{firstWord}</em> {rest}</h1>
        <div className="pv-tagline">{r.tagline}</div>
      </div>
      <div className="pv-meta">
        <span className="pv-pill"><span className="dot" /><b>{r.totalMinutes}</b> min</span>
        <span className="pv-pill"><b>{r.servings}</b> servings</span>
        <span className="pv-pill"><b>{r.difficulty}</b></span>
        <span className="pv-pill"><b>{r.steps.length}</b> steps</span>
      </div>
      <div className="pv-image">
        <span className="corner-stick">{r.cuisine}</span>
        <span className="tag">[ overhead shot ]</span>
      </div>
      <div className="pv-step">
        <div className="num">Step {activeStep + 1} / {r.steps.length}</div>
        <h4>{step?.title}</h4>
        <p>{step?.detail}</p>
      </div>
      <div className="pv-sides">
        <div className="pv-card">
          <h5>Ingredients <span className="count">· {r.ingredients.length}</span></h5>
          <ul>
            {r.ingredients.slice(0, 5).map((ing, i) => {
              const lib = ING_LIBRARY.find(x => x.id === ing.ingId) || { name: ing.ingId };
              return (
                <li key={i}>
                  <span className="check" />
                  <span>{lib.name}</span>
                  <span className="amt">{ing.amt}{ing.unit ? " " + ing.unit : ""}</span>
                </li>
              );
            })}
          </ul>
        </div>
        <div className="pv-card">
          <h5>Utensils <span className="count">· {r.utensils.length}</span></h5>
          <ul>
            {r.utensils.slice(0, 5).map((u, i) => {
              const lib = UT_LIBRARY.find(x => x.id === u.utId) || { name: u.utId };
              return (
                <li key={i}>
                  <span className="check" />
                  <span>{lib.name}</span>
                  {!u.must && <span style={{ marginLeft: "auto", fontFamily: "var(--mono)", fontSize: 9, color: "var(--ink-faint)", letterSpacing: "0.08em", textTransform: "uppercase" }}>nice</span>}
                </li>
              );
            })}
          </ul>
        </div>
      </div>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<RecipeAdminApp />);
