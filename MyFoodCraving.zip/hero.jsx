// MyFoodCraving — Hero, Manifesto, Personalize, Cooking, CTA components

const CRAVING_PRESETS = [
  { id: "pasta", label: "pasta" },
  { id: "bowl", label: "something fresh" },
  { id: "spicy", label: "spicy" },
  { id: "sweet", label: "sweet" },
  { id: "cozy", label: "cozy" },
  { id: "fresh", label: "light" }
];

// Map free-text → preset id
function mapCraving(text) {
  const t = text.toLowerCase().trim();
  if (!t) return "bowl";
  if (/(pasta|noodle|spaghetti|ramen|carb)/.test(t)) return "pasta";
  if (/(spicy|hot|chili|chilli|sriracha)/.test(t)) return "spicy";
  if (/(sweet|dessert|yogurt|berry|fruit|sugar)/.test(t)) return "sweet";
  if (/(cozy|warm|soup|stew|comfort)/.test(t)) return "cozy";
  if (/(fresh|salad|crisp|light|cold)/.test(t)) return "fresh";
  return "bowl";
}

// ============================================================
// NAV
// ============================================================
function Nav() {
  const scrolled = useScrolled();
  return (
    <nav className={`nav ${scrolled ? "scrolled" : ""}`}>
      <div className="nav-inner">
        <a href="#" className="brand">
          <span className="brand-mark">m</span>
          <span className="brand-name">MyFood<em>Craving</em></span>
        </a>
        <div className="nav-links">
          <a href="#why">Why MFC</a>
          <a href="#personalize">Personalized</a>
          <a href="#cooking">Guided cooking</a>
          <a href="#cta">Get started</a>
        </div>
        <a href="#cta" className="btn btn-primary">Try it free →</a>
      </div>
    </nav>
  );
}

// ============================================================
// HERO
// ============================================================
function Hero() {
  const [cravingId, setCravingId] = useState("bowl");
  const [text, setText] = useState("");
  const meal = CRAVINGS[cravingId];

  const submit = (e) => {
    e?.preventDefault?.();
    setCravingId(mapCraving(text));
  };

  return (
    <section className="hero">
      <div className="wrap">
        <div className="hero-grid">
          <div className="hero-copy reveal">
            <div className="hero-eyebrow-row">
              <span className="eyebrow"><span className="eyebrow-dot" />personalized · guided · delicious</span>
              <span className="scribble" style={{ transform: "rotate(-4deg)" }}>for real bodies ✦</span>
            </div>
            <h1 className="hero-headline">
              Eat what your body's<br />
              <em>actually craving<svg className="underline-scribble" viewBox="0 0 240 14" preserveAspectRatio="none" aria-hidden="true">
                <path d="M2 8 Q 60 2 120 7 T 238 6" stroke="#FF6D2E" strokeWidth="3" fill="none" strokeLinecap="round" />
              </svg></em>.
            </h1>
            <p className="hero-sub">
              Tell us what sounds good. We read your health data, fix the gaps, and walk you through cooking it — like a friend who actually went to culinary school.
            </p>

            <form className="hero-craving" onSubmit={submit}>
              <div className="craving-input-row">
                <input
                  className="craving-input"
                  placeholder="something with pasta, but make it healthy…"
                  value={text}
                  onChange={(e) => setText(e.target.value)}
                />
                <button className="craving-go" type="submit" aria-label="Find meals">→</button>
              </div>
              <div className="craving-chips">
                {CRAVING_PRESETS.map(c => (
                  <button
                    type="button"
                    key={c.id}
                    className={`chip ${cravingId === c.id ? "active" : ""}`}
                    onClick={() => { setCravingId(c.id); setText(""); }}
                  >{c.label}</button>
                ))}
              </div>
            </form>

            <div className="hero-mini">
              <span>✓ <b>12k+</b> meals personalized</span>
              <span>✓ syncs with <b>Apple Health</b> + <b>Google Fit</b></span>
              <span>✓ <b>4.8★</b> avg rating</span>
            </div>
          </div>

          <div className="plate-stage reveal">
            <span className="deco" style={{ top: "-2%", left: "-4%", fontSize: 44 }}>🌿</span>
            <span className="deco float-bob" style={{ top: "10%", right: "-2%", fontSize: 38 }}>🍅</span>
            <span className="deco float-bob-2" style={{ bottom: "8%", right: "-4%", fontSize: 40 }}>🍋</span>

            <div className="plate" key={cravingId}>
              <div className="plate-content">
                <div className="plate-photo" />
              </div>
            </div>

            <div className="sticker sticker-orange tilt-l sticker-1">
              <span className="dot" />
              <div>
                <div style={{ fontSize: 11, color: "var(--ink-muted)", fontFamily: "var(--mono)", letterSpacing: "0.08em", textTransform: "uppercase" }}>Lunch · suggested</div>
                <div style={{ fontFamily: "var(--serif)", fontStyle: "italic", fontSize: 18, lineHeight: 1.1, marginTop: 2 }}>{meal.name}</div>
              </div>
            </div>

            <div className="sticker tilt-r sticker-2">
              <span className="dot" />
              <span>{meal.tags[0]}</span>
            </div>

            <div className="sticker sticker-orange tilt-r sticker-3">
              <span className="dot" />
              <span>ready in {meal.blurb.split("·").pop().trim()}</span>
            </div>

            <div className="sticker-macros">
              <div className="m"><div className="v">{meal.kcal}</div><div className="u">kcal</div></div>
              <div className="m"><div className="v">{meal.p}g</div><div className="u">protein</div></div>
              <div className="m"><div className="v">{meal.c}g</div><div className="u">carbs</div></div>
              <div className="m"><div className="v">{meal.f}g</div><div className="u">fat</div></div>
            </div>

            <div className="scribble-arrow" style={{ top: "44%", right: "-12%", maxWidth: 130, transform: "rotate(8deg)" }}>
              your body asked for this →
            </div>
          </div>
        </div>
      </div>

      <div className="marquee" aria-hidden="true">
        <div className="marquee-track">
          {[...Array(2)].map((_, i) => (
            <React.Fragment key={i}>
              <span className="marquee-item">read your blood work</span>
              <span className="marquee-item">cook with confidence</span>
              <span className="marquee-item">no calorie counting</span>
              <span className="marquee-item">close your nutrition gaps</span>
              <span className="marquee-item">pasta is back on the menu</span>
              <span className="marquee-item">crave smarter, not less</span>
            </React.Fragment>
          ))}
        </div>
      </div>
    </section>
  );
}

// ============================================================
// MANIFESTO
// ============================================================
function Manifesto() {
  return (
    <section className="manifesto" id="why">
      <div className="wrap">
        <div className="manifesto-grid">
          <div className="reveal">
            <div className="eyebrow" style={{ background: "rgba(247,241,227,0.08)", color: "var(--cream)", borderColor: "rgba(247,241,227,0.2)", marginBottom: 28 }}>
              <span className="eyebrow-dot" /> the problem
            </div>
            <h2 className="manifesto-headline">
              Diets <span className="strike">lied</span> to you.<br />
              Recipe apps <em>guessed</em>.<br />
              Your body deserved better.
            </h2>
          </div>
          <div className="manifesto-side reveal">
            <div className="lies-list">
              <div className="lie">
                <span className="lie-num">01</span>
                <p className="lie-text">Calorie counting <span className="strike">tracked your food</span>, but it never knew you were <b>iron-deficient</b>.</p>
              </div>
              <div className="lie">
                <span className="lie-num">02</span>
                <p className="lie-text">Generic meal plans gave 47 million people <b>the same</b> 1800-cal salad.</p>
              </div>
              <div className="lie">
                <span className="lie-num">03</span>
                <p className="lie-text">Recipe apps showed you the dish but <b>never how to cook it</b> when you've never held a chef's knife.</p>
              </div>
              <div className="lie">
                <span className="lie-num">04</span>
                <p className="lie-text">Cravings got framed as the enemy. They're <b>your body talking</b>. We translate.</p>
              </div>
            </div>
            <blockquote className="quote-card">
              "Three apps gave me the same plan. None of them knew my B12 was tanked. MFC figured it out in five minutes."
              <div className="quote-attrib">— Priya, design lead, six months on MFC</div>
            </blockquote>
          </div>
        </div>
      </div>
    </section>
  );
}

window.Nav = Nav;
window.Hero = Hero;
window.Manifesto = Manifesto;
