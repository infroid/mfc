// Ingredient admin — simplified, AI-filled
const { useState } = React;

const SAMPLE_ING = {
  id: "paneer",
  name: "Paneer",
  tagline: "fresh, milky, holds shape under heat",
  category: "Dairy",
  defaultUnit: "g",
  photoFile: "paneer-block-1600.jpg",
  photoSize: "1.8 MB · 1600×1200",
  // Optional fields — each gated by a "show" toggle
  show: {
    nutrition: true,
    healthFact: true,
    storage: false,
    substitutes: false
  },
  nutrition: { calories: 265, protein: 18, fat: 21, carbs: 1.2 },
  healthFact: "About 14g protein per 100g, with ~21% of daily calcium.",
  storage: "Refrigerated, submerged in water · 7 days",
  substitutes: ["tofu (firm)", "halloumi"],
  // Meta
  inRecipes: 18,
  aiStatus: "filled", // 'filled' | 'reviewed' | 'manual'
  aiFilledAt: "2 hours ago"
};

function IngredientAdminApp() {
  const [r, setR] = useState(SAMPLE_ING);
  const [dirty, setDirty] = useState(false);
  const update = (patch) => { setR(p => ({ ...p, ...patch })); setDirty(true); };
  const updateShow = (k, v) => update({ show: { ...r.show, [k]: v } });
  const updateNut = (k, v) => update({ nutrition: { ...r.nutrition, [k]: v } });

  return (
    <div className="admin-shell">
      <AdminSidebar active="ingredients" />
      <div className="admin-main">
        <AdminTopbar
          crumb={[{ label: "Ingredients", href: "#" }, { label: r.name || "Untitled" }]}
          status="live"
          savedAgo="2 min ago"
        />

        <div className="admin-page">
          <div className="admin-page-head">
            <div>
              <h1>Edit <em>ingredient</em></h1>
              <p className="lede">Library entry — used by {r.inRecipes} recipes. Most fields are auto-filled by AI; you only review and toggle what should surface to users.</p>
            </div>
            <div className="admin-page-meta">
              <span><b>id</b> · {r.id}</span>
              <span><b>{r.inRecipes}</b> recipes</span>
              <span style={{ color: "var(--matcha-deep)" }}><b>✦</b> ai-filled</span>
            </div>
          </div>

          {/* AI banner */}
          <div className="ai-banner">
            <div className="glyph">✦</div>
            <div className="copy">
              <b>Auto-filled by Claude · {r.aiFilledAt}</b>
              <span>Identity, photo, and nutrition were generated. Review the values, toggle which optional fields should appear to users, and publish.</span>
            </div>
            <div className="actions">
              <button className="btn-sm ghost">↻ Re-run</button>
              <button className="btn-sm primary">✓ Looks good</button>
            </div>
          </div>

          <div className="workbench">
            <div className="workbench-form">

              {/* Core — what's always shown */}
              <FormCard title="Core" scribble="always shown">
                <div className="field-grid">
                  <Field label="Name" required>
                    <input className="input serif" value={r.name} onChange={e => update({ name: e.target.value })} />
                  </Field>
                  <div className="field-grid cols-2">
                    <Field label="Tagline" help="one line">
                      <input className="input" value={r.tagline} onChange={e => update({ tagline: e.target.value })} />
                    </Field>
                    <Field label="Category">
                      <select className="select" value={r.category} onChange={e => update({ category: e.target.value })}>
                        <option>Dairy</option><option>Vegetable</option><option>Fruit</option><option>Grain</option><option>Spice</option><option>Herb</option><option>Protein</option><option>Oil & Fat</option><option>Nut & Seed</option>
                      </select>
                    </Field>
                  </div>
                  <Field label="Photo" required hint="One clean shot. Surfaces in recipes & search.">
                    <Uploader filename={r.photoFile} size={r.photoSize} onClear={() => update({ photoFile: null })} />
                  </Field>
                </div>
              </FormCard>

              {/* Nutrition — toggle-gated */}
              <SurfaceCard
                title="Nutrition"
                scribble="per 100g"
                surfaceLabel="recipe & ingredient page"
                show={r.show.nutrition}
                onShowChange={v => updateShow("nutrition", v)}
                aiBadge
              >
                <div className="nut-grid" style={{ gridTemplateColumns: "repeat(4, 1fr)" }}>
                  <NutCell label="Calories" value={r.nutrition.calories} unit="kcal" onChange={v => updateNut("calories", v)} accent />
                  <NutCell label="Protein" value={r.nutrition.protein} unit="g" onChange={v => updateNut("protein", v)} />
                  <NutCell label="Fat" value={r.nutrition.fat} unit="g" onChange={v => updateNut("fat", v)} />
                  <NutCell label="Carbs" value={r.nutrition.carbs} unit="g" onChange={v => updateNut("carbs", v)} />
                </div>
                <div style={{ marginTop: 12, fontSize: 12, color: "var(--ink-muted)", fontStyle: "italic", fontFamily: "var(--serif)" }}>
                  Only the four macros surface in the UI. Detailed micros are stored but hidden.
                </div>
              </SurfaceCard>

              {/* Health fact */}
              <SurfaceCard
                title="Health fact"
                scribble="rotates in cooking flow"
                surfaceLabel="recipe page · health rotator"
                show={r.show.healthFact}
                onShowChange={v => updateShow("healthFact", v)}
                aiBadge
              >
                <Field label="One-liner" help="60–110 chars">
                  <textarea
                    className="textarea"
                    rows={2}
                    value={r.healthFact}
                    onChange={e => update({ healthFact: e.target.value })}
                  />
                </Field>
              </SurfaceCard>

              {/* Storage */}
              <SurfaceCard
                title="Storage tip"
                surfaceLabel="ingredient page only"
                show={r.show.storage}
                onShowChange={v => updateShow("storage", v)}
              >
                <Field label="Where & how long">
                  <input className="input" value={r.storage} onChange={e => update({ storage: e.target.value })} placeholder="Refrigerated, submerged in water · 7 days" />
                </Field>
              </SurfaceCard>

              {/* Substitutes */}
              <SurfaceCard
                title="Substitutes"
                surfaceLabel="ingredient page only"
                show={r.show.substitutes}
                onShowChange={v => updateShow("substitutes", v)}
              >
                <Field label="Similar ingredients" hint="Press enter to add">
                  <ChipInput
                    color="matcha"
                    tags={r.substitutes}
                    onAdd={t => update({ substitutes: [...r.substitutes, t] })}
                    onRemove={i => update({ substitutes: r.substitutes.filter((_, k) => k !== i) })}
                    placeholder="tofu, halloumi…"
                  />
                </Field>
              </SurfaceCard>

              {/* Footer note about scope */}
              <div style={{ padding: 16, background: "var(--cream-soft)", border: "1px dashed var(--rule-strong)", borderRadius: 12, fontSize: 13, color: "var(--ink-soft)", lineHeight: 1.55 }}>
                <b style={{ fontFamily: "var(--mono)", fontSize: 10, letterSpacing: "0.1em", textTransform: "uppercase", color: "var(--orange)", display: "block", marginBottom: 6 }}>That's it.</b>
                We deliberately keep ingredient entries minimal. If you need a field to surface that isn't above, ping the schema team — we add fields only when they earn screen time.
              </div>

            </div>

            <div className="workbench-preview">
              <PreviewFrame url={`/i/${r.id}`}>
                <IngredientPreview r={r} />
              </PreviewFrame>
              <div style={{ display: "flex", gap: 8, alignItems: "center", padding: "0 4px", fontFamily: "var(--mono)", fontSize: 10, letterSpacing: "0.08em", textTransform: "uppercase", color: "var(--ink-muted)" }}>
                <span>↻ Live preview</span>
                <span>·</span>
                <span>What users will see</span>
              </div>
            </div>
          </div>

          <SaveBar dirty={dirty} onDiscard={() => {}} onSaveDraft={() => setDirty(false)} onPublish={() => setDirty(false)} />
        </div>
      </div>
    </div>
  );
}

// ============================================================
// SURFACE CARD — a card with a "show in user-facing output" toggle
// ============================================================
function SurfaceCard({ title, scribble, surfaceLabel, show, onShowChange, aiBadge, children }) {
  return (
    <section className="form-card" style={!show ? { opacity: 0.6 } : {}}>
      <div className="form-card-head">
        <h3>
          {title}
          {aiBadge && (
            <span style={{ fontFamily: "var(--mono)", fontStyle: "normal", fontSize: 9, letterSpacing: "0.1em", color: "var(--matcha-deep)", background: "var(--matcha-soft)", padding: "2px 6px", borderRadius: 4, fontWeight: 600, marginLeft: 4 }}>✦ AI</span>
          )}
        </h3>
        {scribble && <span className="scribble-note">{scribble}</span>}
        <div style={{ marginLeft: "auto", display: "flex", alignItems: "center", gap: 10 }}>
          <span style={{ fontFamily: "var(--mono)", fontSize: 9, letterSpacing: "0.1em", textTransform: "uppercase", color: show ? "var(--matcha-deep)" : "var(--ink-faint)" }}>
            {show ? `↗ ${surfaceLabel}` : "hidden"}
          </span>
          <Toggle value={show} onChange={onShowChange} />
        </div>
      </div>
      {show && <div className="form-card-body compact">{children}</div>}
      {!show && (
        <div style={{ padding: "14px 24px", background: "var(--cream-soft)", borderTop: "1px dashed var(--rule)", fontSize: 12, color: "var(--ink-muted)", fontStyle: "italic", fontFamily: "var(--serif)" }}>
          Toggle on to include this in the user-facing output.
        </div>
      )}
    </section>
  );
}

function NutCell({ label, value, unit, onChange, accent }) {
  return (
    <div className={"nut-cell" + (accent ? " accent" : "")}>
      <div className="lbl">{label}</div>
      <div className="row">
        <input value={value} onChange={e => onChange(e.target.value)} />
        <span className="unit">{unit}</span>
      </div>
    </div>
  );
}

// ============================================================
// LIVE PREVIEW — exactly what the user sees
// ============================================================
function IngredientPreview({ r }) {
  const firstWord = (r.name || "").split(" ")[0];
  const rest = (r.name || "").split(" ").slice(1).join(" ");
  return (
    <div className="pv-ing-card">
      <div className="pv-ing-photo">
        <span className="badge">{r.category}</span>
        <span className="tag">[ {r.photoFile || "no-photo.jpg"} ]</span>
      </div>
      <div className="pv-ing-body">
        <div className="pv-ing-name">
          {rest ? <><em>{firstWord}</em> {rest}</> : firstWord}
        </div>
        <div className="pv-ing-tagline">{r.tagline}</div>

        {r.show.nutrition && (
          <div className="pv-nut-strip">
            <div className="cell"><div className="v">{r.nutrition.calories}</div><div className="l">kcal</div></div>
            <div className="cell"><div className="v">{r.nutrition.protein}g</div><div className="l">protein</div></div>
            <div className="cell"><div className="v">{r.nutrition.fat}g</div><div className="l">fat</div></div>
            <div className="cell"><div className="v">{r.nutrition.carbs}g</div><div className="l">carbs</div></div>
          </div>
        )}

        {r.show.healthFact && (
          <div style={{ marginTop: 14, padding: "12px 14px", background: "var(--matcha-soft)", borderRadius: 10, fontSize: 13, color: "var(--matcha-deep)", fontStyle: "italic", fontFamily: "var(--serif)", lineHeight: 1.45 }}>
            <span style={{ fontFamily: "var(--mono)", fontStyle: "normal", fontSize: 9, letterSpacing: "0.1em", textTransform: "uppercase", color: "var(--matcha-deep)", display: "block", marginBottom: 4, opacity: 0.7 }}>did you know</span>
            {r.healthFact}
          </div>
        )}

        {r.show.storage && (
          <div style={{ marginTop: 12, fontFamily: "var(--mono)", fontSize: 11, color: "var(--ink-muted)", display: "flex", gap: 8 }}>
            <span style={{ color: "var(--orange)" }}>storage</span>
            <span>{r.storage}</span>
          </div>
        )}

        {r.show.substitutes && r.substitutes.length > 0 && (
          <div style={{ marginTop: 12 }}>
            <div style={{ fontFamily: "var(--mono)", fontSize: 9, letterSpacing: "0.1em", textTransform: "uppercase", color: "var(--ink-muted)", marginBottom: 6 }}>or use</div>
            <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
              {r.substitutes.map((s, i) => (
                <span key={i} style={{ padding: "3px 9px", background: "var(--matcha-soft)", color: "var(--matcha-deep)", borderRadius: 999, fontSize: 11 }}>{s}</span>
              ))}
            </div>
          </div>
        )}

        <div style={{ marginTop: 14, paddingTop: 12, borderTop: "1px dashed var(--rule)", fontFamily: "var(--mono)", fontSize: 10, color: "var(--ink-faint)", letterSpacing: "0.08em", textTransform: "uppercase" }}>
          used in {r.inRecipes} recipes
        </div>
      </div>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<IngredientAdminApp />);
