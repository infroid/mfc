// Admin shared components — shell, sidebar, topbar, save bar, form primitives
const { useState, useEffect, useRef, useMemo } = React;

// ============================================================
// SIDEBAR
// ============================================================
function AdminSidebar({ active }) {
  const items = [
    { group: "Library", entries: [
      { id: "recipes", icon: "✦", label: "Recipes", count: 142, href: "admin-recipe.html" },
      { id: "ingredients", icon: "◐", label: "Ingredients", count: 318, href: "admin-ingredient.html" },
      { id: "utensils", icon: "▣", label: "Utensils", count: 47, href: "admin-utensil.html" },
      { id: "collections", icon: "❖", label: "Collections", count: 12, href: "#" }
    ]},
    { group: "Operate", entries: [
      { id: "users", icon: "○", label: "Users", count: "12.4k", href: "#" },
      { id: "feedback", icon: "✿", label: "Feedback", count: 23, href: "#" },
      { id: "analytics", icon: "△", label: "Analytics", href: "#" }
    ]},
    { group: "Settings", entries: [
      { id: "brand", icon: "❀", label: "Brand & tone", href: "#" },
      { id: "publish", icon: "↗", label: "Publishing", href: "#" }
    ]}
  ];
  return (
    <aside className="admin-side">
      <a href="index.html" className="admin-brand">
        <span className="brand-mark">m</span>
        <span className="brand-name">my<em>food</em>craving</span>
        <span className="admin-tag">admin</span>
      </a>
      {items.map(g => (
        <div key={g.group} className="admin-nav-group">
          <div className="admin-nav-label">{g.group}</div>
          {g.entries.map(e => (
            <a key={e.id} href={e.href} className={"admin-nav-item" + (active === e.id ? " active" : "")}>
              <span className="ic">{e.icon}</span>
              <span>{e.label}</span>
              {e.count !== undefined && <span className="count">{e.count}</span>}
            </a>
          ))}
        </div>
      ))}
      <div className="admin-side-foot">
        <div className="admin-avatar">A</div>
        <div className="who"><b>Asha P.</b><span>chief curator</span></div>
      </div>
    </aside>
  );
}

// ============================================================
// TOPBAR
// ============================================================
function AdminTopbar({ crumb, status, savedAgo, onPreview, onPublish, isNew }) {
  return (
    <div className="admin-topbar">
      <div className="admin-crumb">
        <a href="#">Admin</a>
        {crumb.map((c, i) => (
          <React.Fragment key={i}>
            <span className="sep">›</span>
            {i === crumb.length - 1
              ? <span className="current">{c.label}</span>
              : <a href={c.href || "#"}>{c.label}</a>}
          </React.Fragment>
        ))}
      </div>
      <div className="admin-topbar-spacer" />
      {status && (
        <span className={"admin-status " + status}>
          <span className="dot" />
          {status === "draft" ? "Draft" : status === "live" ? "Live" : "Archived"}
        </span>
      )}
      {savedAgo && (
        <span className="admin-saved">
          <span className="check">✓</span>
          Auto-saved {savedAgo}
        </span>
      )}
      <div className="admin-actions">
        <button className="btn-sm ghost" onClick={onPreview}>Preview</button>
        <button className="btn-sm primary" onClick={onPublish}>{isNew ? "Publish" : "Update"}</button>
      </div>
    </div>
  );
}

// ============================================================
// SAVE BAR (sticky bottom)
// ============================================================
function SaveBar({ dirty, onDiscard, onSaveDraft, onPublish, isNew }) {
  return (
    <div className="save-bar">
      <div className="info">
        {dirty && <span className="dirty-dot" />}
        <span>{dirty ? "Unsaved changes — auto-save in 8s" : "All changes saved"}</span>
      </div>
      <div className="actions">
        <button className="btn-sm ghost" onClick={onDiscard}>Discard</button>
        <button className="btn-sm" onClick={onSaveDraft}>Save draft</button>
        <button className="btn-sm primary" onClick={onPublish}>{isNew ? "Publish recipe →" : "Update & republish →"}</button>
      </div>
    </div>
  );
}

// ============================================================
// FORM TABS
// ============================================================
function FormTabs({ tabs, active, onChange }) {
  return (
    <div className="form-tabs">
      {tabs.map(t => (
        <button
          key={t.id}
          className={"form-tab" + (active === t.id ? " active" : "")}
          onClick={() => onChange(t.id)}
        >
          {t.label}
          {t.badge && <span className="badge">{t.badge}</span>}
        </button>
      ))}
    </div>
  );
}

// ============================================================
// FORM CARD
// ============================================================
function FormCard({ title, stepNo, scribble, headRight, children }) {
  return (
    <section className="form-card">
      <div className="form-card-head">
        <h3>
          {stepNo && <span className="step-no">{stepNo}</span>}
          {title}
        </h3>
        {scribble && <span className="scribble-note">{scribble}</span>}
        {headRight}
      </div>
      <div className="form-card-body">{children}</div>
    </section>
  );
}

// ============================================================
// FIELD primitives
// ============================================================
function Field({ label, required, hint, help, children }) {
  return (
    <div className="field">
      <div className="field-label">
        <span>{label}</span>
        {required && <span className="req">*</span>}
        {help && <span className="help">{help}</span>}
      </div>
      {children}
      {hint && <div className="field-hint">{hint}</div>}
    </div>
  );
}

function RadioPills({ value, options, onChange }) {
  return (
    <div className="radio-pills">
      {options.map(o => {
        const v = typeof o === "string" ? o : o.value;
        const l = typeof o === "string" ? o : o.label;
        return (
          <button
            key={v}
            type="button"
            className={"pill" + (value === v ? " active" : "")}
            onClick={() => onChange(v)}
          >{l}</button>
        );
      })}
    </div>
  );
}

function Toggle({ value, onChange }) {
  return (
    <button type="button" className={"toggle" + (value ? " on" : "")} onClick={() => onChange(!value)} />
  );
}

function ToggleRow({ name, desc, value, onChange }) {
  return (
    <div className="toggle-row">
      <div className="copy">
        <div className="name">{name}</div>
        {desc && <div className="desc">{desc}</div>}
      </div>
      <Toggle value={value} onChange={onChange} />
    </div>
  );
}

function ChipInput({ tags, onAdd, onRemove, placeholder = "Add tag…", color }) {
  const [draft, setDraft] = useState("");
  function commit() {
    const v = draft.trim();
    if (v) { onAdd(v); setDraft(""); }
  }
  return (
    <div className="chip-input">
      {tags.map((t, i) => (
        <span key={i} className={"tag " + (color || "")}>
          {t}
          <span className="x" onClick={() => onRemove(i)}>×</span>
        </span>
      ))}
      <input
        value={draft}
        onChange={e => setDraft(e.target.value)}
        onKeyDown={e => {
          if (e.key === "Enter" || e.key === ",") { e.preventDefault(); commit(); }
          else if (e.key === "Backspace" && !draft && tags.length) onRemove(tags.length - 1);
        }}
        onBlur={commit}
        placeholder={placeholder}
      />
    </div>
  );
}

function Uploader({ filename, size, caption, badge, hint, onClear }) {
  if (filename) {
    return (
      <div className="uploader has-image">
        <div className="uploader-img" />
        <div className="uploader-meta">
          <div>
            <div className="name">{filename}</div>
            <div className="size">{size}</div>
          </div>
          <span className="replace" onClick={onClear}>Replace</span>
        </div>
      </div>
    );
  }
  return (
    <div className="uploader">
      <div className="uploader-glyph">↑</div>
      <div className="uploader-title">{caption || "Drop a photo here"}</div>
      <div className="uploader-hint">{hint || "PNG / JPG · 1600×1200 recommended"}</div>
    </div>
  );
}

function PreviewFrame({ url, tabs = ["Desktop", "Mobile"], children }) {
  const [tab, setTab] = useState(tabs[0]);
  return (
    <div className="preview-frame">
      <div className="preview-bar">
        <span className="dots"><span /><span /><span /></span>
        <span className="url">myfoodcraving.com{url}</span>
        <div className="pv-tabs">
          {tabs.map(t => (
            <button key={t} className={"pv-tab" + (tab === t ? " active" : "")} onClick={() => setTab(t)}>{t}</button>
          ))}
        </div>
      </div>
      <div className="preview-body">{children}</div>
    </div>
  );
}

Object.assign(window, {
  AdminSidebar, AdminTopbar, SaveBar, FormTabs, FormCard, Field,
  RadioPills, Toggle, ToggleRow, ChipInput, Uploader, PreviewFrame
});
