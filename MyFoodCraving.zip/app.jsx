// MyFoodCraving — playful, editorial landing
const { useState, useEffect, useRef, useMemo } = React;

// ============================================================
// DATA
// ============================================================
const CRAVINGS = {
  pasta: {
    name: "Lemon Ricotta Spaghetti",
    blurb: "carb · cozy · 30 min",
    kcal: 520, p: 22, c: 68, f: 18,
    tags: ["high B12", "low sodium", "gluten-flexible"],
    why: "Bright, brothy, and hits your iron + B12 marks without the food-coma carbs."
  },
  bowl: {
    name: "Mediterranean Quinoa Bowl",
    blurb: "fresh · proteins · 30 min",
    kcal: 480, p: 32, c: 48, f: 18,
    tags: ["+47% iron", "high fiber", "vegan-able"],
    why: "Quinoa, chickpeas, and tahini stack iron and protein — exactly what your panel wants today."
  },
  spicy: {
    name: "Gochujang Salmon Rice",
    blurb: "spicy · omega-3 · 25 min",
    kcal: 590, p: 38, c: 52, f: 24,
    tags: ["omega-3", "high B12", "spicy"],
    why: "Salmon for omega-3 + B12, gochujang heat, rice cushion. Your body says yes."
  },
  sweet: {
    name: "Greek Yogurt Berry Cup",
    blurb: "sweet · light · 5 min",
    kcal: 310, p: 24, c: 38, f: 6,
    tags: ["high protein", "antioxidants", "low cal"],
    why: "Sugar craving without the sugar crash. Berries deliver iron-cofactor vitamin C."
  },
  cozy: {
    name: "Miso Mushroom Soup",
    blurb: "warm · umami · 20 min",
    kcal: 340, p: 18, c: 32, f: 12,
    tags: ["gut-friendly", "low cal", "vegetarian"],
    why: "Miso for gut flora, mushrooms for vitamin D. Comfort that earns its keep."
  },
  fresh: {
    name: "Citrus Avocado Salad",
    blurb: "fresh · crisp · 10 min",
    kcal: 380, p: 12, c: 24, f: 28,
    tags: ["healthy fats", "vitamin C", "fiber"],
    why: "Healthy fats from avocado + vitamin C from citrus help your iron actually absorb."
  }
};

const HEALTH_METRICS = [
  { id: "iron", name: "Iron", sub: "Below range", val: "9.2 g/dL", default: true },
  { id: "b12", name: "B12", sub: "Within range", val: "412 pg/mL", default: true },
  { id: "sodium", name: "Sodium watch", sub: "Reduce intake", val: "−15%", default: true },
  { id: "fiber", name: "Fiber goal", sub: "Increase daily", val: "+25g", default: false }
];

const COOKING_STEPS = [
  {
    id: 1,
    title: "Prep & rinse",
    detail: "Rinse 1 cup quinoa under cold water until it runs clear. Drain well — this kills the bitter coating.",
    duration: 90
  },
  {
    id: 2,
    title: "Dice the crew",
    detail: "Cucumber, cherry tomatoes, red onion — small dice, roughly the size of the quinoa.",
    duration: 240
  },
  {
    id: 3,
    title: "Simmer the grain",
    detail: "Bring 2 cups water to a boil. Add quinoa, cover, reduce to low. Simmer 15 min until water is gone.",
    duration: 900
  },
  {
    id: 4,
    title: "Whisk the dressing",
    detail: "Tahini, lemon juice, olive oil, garlic, salt. Whisk until creamy — add water if too thick.",
    duration: 180
  },
  {
    id: 5,
    title: "Toss & taste",
    detail: "Combine fluffed quinoa with veg, dressing, parsley, and a handful of crumbled feta. Adjust salt.",
    duration: 120
  }
];

const INGREDIENTS = [
  { name: "Quinoa", amt: "1 cup" },
  { name: "Cucumber", amt: "1 small" },
  { name: "Cherry tomatoes", amt: "1.5 cups" },
  { name: "Red onion", amt: "½ small" },
  { name: "Tahini", amt: "3 tbsp" },
  { name: "Lemon", amt: "1 large" },
  { name: "Feta", amt: "⅓ cup" },
  { name: "Parsley", amt: "1 bunch" }
];

// ============================================================
// HOOKS
// ============================================================
function useReveal() {
  useEffect(() => {
    const els = document.querySelectorAll(".reveal");
    if (!("IntersectionObserver" in window)) {
      els.forEach(el => el.classList.add("visible"));
      return;
    }
    const io = new IntersectionObserver(entries => {
      entries.forEach(e => {
        if (e.isIntersecting) {
          e.target.classList.add("visible");
          io.unobserve(e.target);
        }
      });
    }, { threshold: 0.08, rootMargin: "0px 0px -40px 0px" });
    els.forEach(el => io.observe(el));
    return () => io.disconnect();
  }, []);
}

function useScrolled() {
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    window.addEventListener("scroll", onScroll, { passive: true });
    onScroll();
    return () => window.removeEventListener("scroll", onScroll);
  }, []);
  return scrolled;
}

window.useReveal = useReveal;
window.useScrolled = useScrolled;
window.CRAVINGS = CRAVINGS;
window.HEALTH_METRICS = HEALTH_METRICS;
window.COOKING_STEPS = COOKING_STEPS;
window.INGREDIENTS = INGREDIENTS;
