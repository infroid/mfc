// Utensil admin — simplified, AI-filled
const { useState } = React;

const SAMPLE_UT = {
  id: "kadhai-cast-iron-9",
  name: "Cast-iron kadhai",
  tagline: "deep, broad, hot — the workhorse pan",
  category: "Cookware",
  photoFile: "kadhai-3-4-angle.jpg",
  photoSize: "1.4 MB · 1600×1600",
  // Optional fields — gated
  show: {
    buyLink: true,
    careTip: true,
    specs: false
  },
  buyLink: { store: "Amazon", url: "amazon.com/dp/B07JFTSKXW?tag=mfc-20", price: "$49.95" },
  careTip: "Hand-wash with warm water — no soap. Dry on heat, oil while warm.",
  specs: { material: "Cast iron", size: "9-inch (23 cm)", weight: "1.8 kg" },
  // Meta
  inRecipes: 34,
  aiFilledAt: "1 hour ago"
};

function UtensilAdminApp() {
  const [r, setR] = useState(SAMPLE_UT);
  const [dirty, setDirty] = useState(false);
  const update = (patch) => { setR(p => ({ ...p, ...patch })); setDirty(true); };
  const updateShow = (k, v) => update({ show: { ...r.show, [k]: v } });
  const updateBuy = (k, v) => update({ buyLink: { ...r.buyLink, [k]: v } });
  const updateSpec = (k, v) => update({ specs: { ...r.specs, [k]: v } });

  return (
    <div className="admin-shell">
      <AdminSidebar active="utensils" />
      <div className="admin-main">
        <AdminTopbar
          crumb={[{ label: "Utensils", href: "#" }, { label: r.name }]}
          status="live"
          savedAgo="5 min ago"
        />

        <div className="admin-page">
          <div className="admin-page-head">
            <div>
              <h1>Edit <em>utensil</em></h1>
              <p className="lede">Library entry — used by {r.inRecipes} recipes. AI fills the basics; you decide what surfaces.</p>
            </div>
            <div className="admin-page-meta">
              <span><b>id</b> · {r.id}</span>
              <span><b>{r.inRecipes}</b> recipes</span>
              <span style={{ color: "var(--matcha-deep)" }}><b>✦</b> ai-filled</span>
            </div>
          </div>

          <div className="ai-banner">
            <div className="glyph">✦</div>
            <div className="copy">
              <b>Auto-filled by Claude · {r.aiFilledAt}</b>
              <span>Identity, photo, and Amazon link were generated. Review, toggle which fields appear, publish.</span>
            </div>
            <div className="actions">
              <button className="btn-sm ghost">↻ Re-run</button>
              <button className="btn-sm primary">✓ Looks good</button>
            </div>
          </div>

          <div className="workbench">
            <div className="workbench-form">

              <FormCard title="Core" scribble="always shown">
                <div className="field-grid">
                  <Field label="Name" required>
                    <input className="input serif" value={r.name} onChange={e => update({ name: e.target.value })} />
                  </Field>
                  <div className="field-grid cols-2">
                    <Field label="Tagline" help="one line">
                      <input className="input" value={r.tagline} onChange={e => update({ tagline: e.target.value })} />
                    </Field>
                    <Field label="Category">
                      <select className="select" value={r.category} onChange={e => update({ category: e.target.value })}>
                        <option>Cookware</option><option>Bakeware</option><option>Cutlery</option><option>Small appliance</option><option>Utensil</option><option>Measuring</option>
                      </select>
                    </Field>
                  </div>
                  <Field label="Photo" required hint="One clean shot. Surfaces in the recipe sidebar.">
                    <Uploader filename={r.photoFile} size={r.photoSize} onClear={() => update({ photoFile: null })} />
                  </Field>
                </div>
              </FormCard>

              {/* Buy link */}
              <SurfaceCard
                title="Buy link"
                scribble="affiliate"
                surfaceLabel="recipe sidebar · utensil page"
                show={r.show.buyLink}
                onShowChange={v => updateShow("buyLink", v)}
                aiBadge
              >
                <div className="link-card amazon" style={{ marginBottom: 10 }}>
                  <div className="platform">a</div>
                  <input
                    className="url-input"
                    value={r.buyLink.url}
                    onChange={e => updateBuy("url", e.target.value)}
                  />
                  <input
                    style={{ width: 80, background: "var(--paper)", border: "1px solid var(--rule)", borderRadius: 6, padding: "4px 8px", fontFamily: "var(--mono)", fontSize: 12, color: "var(--orange)", fontWeight: 600, outline: "none", textAlign: "right" }}
                    value={r.buyLink.price}
                    onChange={e => updateBuy("price", e.target.value)}
                  />
                </div>
                <div style={{ fontSize: 12, color: "var(--ink-muted)", fontStyle: "italic", fontFamily: "var(--serif)" }}>
                  Affiliate tag <span style={{ fontFamily: "var(--mono)", fontStyle: "normal", color: "var(--orange)" }}>mfc-20</span> is appended automatically. Click metrics tracked separately.
                </div>
              </SurfaceCard>

              {/* Care tip */}
              <SurfaceCard
                title="Care tip"
                surfaceLabel="utensil page only"
                show={r.show.careTip}
                onShowChange={v => updateShow("careTip", v)}
                aiBadge
              >
                <Field label="One-liner">
                  <textarea
                    className="textarea"
                    rows={2}
                    value={r.careTip}
                    onChange={e => update({ careTip: e.target.value })}
                  />
                </Field>
              </SurfaceCard>

              {/* Specs */}
              <SurfaceCard
                title="Specs"
                surfaceLabel="utensil page only"
                show={r.show.specs}
                onShowChange={v => updateShow("specs", v)}
              >
                <div className="field-grid cols-3">
                  <Field label="Material">
                    <input className="input" value={r.specs.material} onChange={e => updateSpec("material", e.target.value)} />
                  </Field>
                  <Field label="Size">
                    <input className="input" value={r.specs.size} onChange={e => updateSpec("size", e.target.value)} />
                  </Field>
                  <Field label="Weight">
                    <input className="input" value={r.specs.weight} onChange={e => updateSpec("weight", e.target.value)} />
                  </Field>
                </div>
              </SurfaceCard>

              <div style={{ padding: 16, background: "var(--cream-soft)", border: "1px dashed var(--rule-strong)", borderRadius: 12, fontSize: 13, color: "var(--ink-soft)", lineHeight: 1.55 }}>
                <b style={{ fontFamily: "var(--mono)", fontSize: 10, letterSpacing: "0.1em", textTransform: "uppercase", color: "var(--orange)", display: "block", marginBottom: 6 }}>That's it.</b>
                Utensils stay simple on purpose. Pros/cons, alternate stores, and ASIN are stored privately and never shown to users.
              </div>

            </div>

            <div className="workbench-preview">
              <PreviewFrame url={`/u/${r.id}`}>
                <UtensilPreview r={r} />
              </PreviewFrame>
              <div style={{ display: "flex", gap: 8, alignItems: "center", padding: "0 4px", fontFamily: "var(--mono)", fontSize: 10, letterSpacing: "0.08em", textTransform: "uppercase", color: "var(--ink-muted)" }}>
                <span>↻ Live preview</span>
                <span>·</span>
                <span>What users will see</span>
              </div>
            </div>
          </div>

          <SaveBar dirty={dirty} onDiscard={() => {}} onSaveDraft={() => setDirty(false)} onPublish={() => setDirty(false)} />
        </div>
      </div>
    </div>
  );
}

// ============================================================
// SURFACE CARD
// ============================================================
function SurfaceCard({ title, scribble, surfaceLabel, show, onShowChange, aiBadge, children }) {
  return (
    <section className="form-card" style={!show ? { opacity: 0.6 } : {}}>
      <div className="form-card-head">
        <h3>
          {title}
          {aiBadge && (
            <span style={{ fontFamily: "var(--mono)", fontStyle: "normal", fontSize: 9, letterSpacing: "0.1em", color: "var(--matcha-deep)", background: "var(--matcha-soft)", padding: "2px 6px", borderRadius: 4, fontWeight: 600, marginLeft: 4 }}>✦ AI</span>
          )}
        </h3>
        {scribble && <span className="scribble-note">{scribble}</span>}
        <div style={{ marginLeft: "auto", display: "flex", alignItems: "center", gap: 10 }}>
          <span style={{ fontFamily: "var(--mono)", fontSize: 9, letterSpacing: "0.1em", textTransform: "uppercase", color: show ? "var(--matcha-deep)" : "var(--ink-faint)" }}>
            {show ? `↗ ${surfaceLabel}` : "hidden"}
          </span>
          <Toggle value={show} onChange={onShowChange} />
        </div>
      </div>
      {show && <div className="form-card-body compact">{children}</div>}
      {!show && (
        <div style={{ padding: "14px 24px", background: "var(--cream-soft)", borderTop: "1px dashed var(--rule)", fontSize: 12, color: "var(--ink-muted)", fontStyle: "italic", fontFamily: "var(--serif)" }}>
          Toggle on to include this in the user-facing output.
        </div>
      )}
    </section>
  );
}

// ============================================================
// LIVE PREVIEW
// ============================================================
function UtensilPreview({ r }) {
  return (
    <div className="pv-ut-card">
      <div className="pv-ut-photo">
        <span className="tag">[ {r.photoFile || "no-photo.jpg"} ]</span>
      </div>
      <div className="pv-ut-body">
        <div className="pv-ut-name">{r.name}</div>
        <div className="pv-ut-tag">{r.category}</div>
        <div style={{ fontSize: 12, color: "var(--ink-soft)", lineHeight: 1.45, margin: "6px 0 8px", fontStyle: "italic", fontFamily: "var(--serif)" }}>
          {r.tagline}
        </div>

        {r.show.specs && (
          <div style={{ display: "flex", flexDirection: "column", gap: 3, marginBottom: 10, fontFamily: "var(--mono)", fontSize: 10, color: "var(--ink-muted)" }}>
            <div><span style={{ color: "var(--ink-faint)" }}>material </span>{r.specs.material}</div>
            <div><span style={{ color: "var(--ink-faint)" }}>size </span>{r.specs.size}</div>
            <div><span style={{ color: "var(--ink-faint)" }}>weight </span>{r.specs.weight}</div>
          </div>
        )}

        {r.show.careTip && (
          <div style={{ marginBottom: 10, padding: "8px 10px", background: "var(--cream-soft)", borderRadius: 8, fontSize: 11, color: "var(--ink-soft)", lineHeight: 1.45, fontStyle: "italic", fontFamily: "var(--serif)" }}>
            <span style={{ fontFamily: "var(--mono)", fontStyle: "normal", fontSize: 8, letterSpacing: "0.1em", textTransform: "uppercase", color: "var(--orange)", display: "block", marginBottom: 2 }}>care</span>
            {r.careTip}
          </div>
        )}

        {r.show.buyLink && (
          <div className="pv-ut-buy">
            <span style={{ marginLeft: 4 }}>· {r.buyLink.price}</span>
          </div>
        )}
      </div>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<UtensilAdminApp />);
