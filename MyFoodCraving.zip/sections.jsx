// MyFoodCraving — Personalize, Cooking, CTA components

// ============================================================
// PERSONALIZE — health metrics drive meal recs
// ============================================================
function MICRO_TARGETS(activeIds) {
  // Macros + key micros, return percent-of-daily for the active rec
  const has = (id) => activeIds.includes(id);
  return [
    { label: "Iron", pct: has("iron") ? 84 : 42, color: "berry", v: has("iron") ? "4.2mg" : "2.1mg" },
    { label: "B12", pct: has("b12") ? 76 : 38, color: "matcha", v: has("b12") ? "3.1µg" : "1.5µg" },
    { label: "Fiber", pct: has("fiber") ? 72 : 48, color: "butter", v: has("fiber") ? "12g" : "8g" },
    { label: "Sodium", pct: has("sodium") ? 28 : 64, color: "orange", v: has("sodium") ? "380mg" : "920mg", inverted: true }
  ];
}

const PERSONA_MEALS = {
  "iron,b12,sodium": { name: "Mediterranean Quinoa Bowl", tags: ["+47% iron", "low sodium", "B12 boost"] },
  "iron,b12": { name: "Gochujang Salmon Rice", tags: ["B12 +60%", "iron-rich", "spicy"] },
  "iron,sodium": { name: "Spinach & Lentil Stew", tags: ["iron-rich", "low sodium", "high fiber"] },
  "b12,sodium": { name: "Miso Salmon & Greens", tags: ["B12 +50%", "low sodium", "omega-3"] },
  "iron": { name: "Spinach & Chickpea Curry", tags: ["iron +60%", "vegetarian"] },
  "b12": { name: "Salmon Poke Bowl", tags: ["B12 boost", "omega-3"] },
  "sodium": { name: "Herb-Roasted Chicken Bowl", tags: ["low sodium", "high protein"] },
  "fiber": { name: "Three-Bean Buddha Bowl", tags: ["fiber +80%", "plant-based"] },
  "default": { name: "Chef's Mixed Grain Bowl", tags: ["balanced", "well-rounded"] }
};

function pickMeal(activeIds) {
  const key = activeIds.slice().sort().join(",");
  if (PERSONA_MEALS[key]) return PERSONA_MEALS[key];
  // fallback: try shorter
  for (const k of Object.keys(PERSONA_MEALS)) {
    const ks = k.split(",");
    if (ks.length && ks.every(x => activeIds.includes(x))) return PERSONA_MEALS[k];
  }
  return PERSONA_MEALS.default;
}

function Ring({ pct, color, label, v, inverted }) {
  const r = 26, c = 2 * Math.PI * r;
  const shown = inverted ? Math.max(0, 100 - pct) : pct;
  const off = c * (1 - Math.min(100, shown) / 100);
  return (
    <div className="ring-cell">
      <svg className="ring-svg" viewBox="0 0 64 64">
        <circle cx="32" cy="32" r={r} fill="none" strokeWidth="6" className="ring-track" />
        <circle cx="32" cy="32" r={r} fill="none" strokeWidth="6"
          className={`ring-fill ${color}`}
          strokeDasharray={c}
          strokeDashoffset={off}
        />
      </svg>
      <div className="ring-pct">{v}</div>
      <div className="ring-label">{label}</div>
    </div>
  );
}

function Personalize() {
  const [active, setActive] = useState(HEALTH_METRICS.filter(m => m.default).map(m => m.id));
  const meal = pickMeal(active);
  const targets = MICRO_TARGETS(active);

  const toggle = (id) => {
    setActive(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);
  };

  return (
    <section className="personalize" id="personalize">
      <div className="wrap">
        <div className="section-head">
          <div className="reveal">
            <div className="eyebrow" style={{ marginBottom: 18 }}><span className="eyebrow-dot" /> live demo · health → plate</div>
            <h2>Your blood work, <em>on a plate.</em></h2>
          </div>
          <p className="lede reveal">
            Toggle a health flag and watch the meal swap. MFC actually reads your panels — iron, B12, sodium, fiber — and suggests food that closes your real gaps. Not a diet plan. Your plan.
          </p>
        </div>

        <div className="personalize-grid">
          <div className="reveal">
            <div className="label-mono" style={{ marginBottom: 12 }}>// your health flags</div>
            <div className="metric-stack">
              {HEALTH_METRICS.map(m => {
                const isOn = active.includes(m.id);
                return (
                  <div
                    key={m.id}
                    className={`metric-card ${isOn ? "active" : ""}`}
                    onClick={() => toggle(m.id)}
                    role="switch"
                    aria-checked={isOn}
                    tabIndex={0}
                    onKeyDown={(e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); toggle(m.id); } }}
                  >
                    <div>
                      <div className="name">{m.name}</div>
                      <div className="sub">{m.sub}</div>
                    </div>
                    <span className="val">{m.val}</span>
                    <span className="toggle" />
                  </div>
                );
              })}
            </div>
            <p className="scribble" style={{ marginTop: 22, fontSize: 24, transform: "rotate(-2deg)" }}>
              tap any to flip it ↑
            </p>
          </div>

          <div className="rec-panel reveal">
            <div className="rec-scribble" style={{ top: -22, right: 24, transform: "rotate(-6deg)" }}>fresh pick ↘</div>
            <div className="rec-head">
              <span className="label-mono">// today's match</span>
              <span style={{ fontFamily: "var(--mono)", fontSize: 11, color: "var(--matcha-deep)" }}>● updated just now</span>
            </div>
            <div className="rec-meal" key={meal.name}>
              <div className="rec-meal-img">[ photo ]</div>
              <div>
                <div className="rec-meal-name">{meal.name}</div>
                <div className="rec-meal-tags">
                  {meal.tags.map((t, i) => (
                    <span key={i} className={`rec-tag ${i === 0 ? "orange" : ""}`}>{t}</span>
                  ))}
                </div>
              </div>
            </div>

            <div className="ring-grid">
              {targets.map(t => <Ring key={t.label} {...t} />)}
            </div>

            <div className="rec-why">
              <b>Why this:</b> {active.length === 0
                ? "No flags active — showing a balanced default. Add a flag to personalize."
                : `Tuned for ${active.map(id => HEALTH_METRICS.find(m => m.id === id)?.name).join(" · ")}. Macros sit inside your goals, micros patch your gaps.`}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

// ============================================================
// COOKING — live timer + advancing steps
// ============================================================
function Cooking() {
  const [stepIdx, setStepIdx] = useState(2);
  const step = COOKING_STEPS[stepIdx];
  const [remaining, setRemaining] = useState(step.duration);
  const [running, setRunning] = useState(true);
  const [checked, setChecked] = useState({ 0: true, 1: true, 2: true });

  // reset timer when step changes
  useEffect(() => { setRemaining(COOKING_STEPS[stepIdx].duration); }, [stepIdx]);

  useEffect(() => {
    if (!running) return;
    const id = setInterval(() => {
      setRemaining(r => {
        if (r <= 1) {
          // auto-advance
          setStepIdx(i => Math.min(i + 1, COOKING_STEPS.length - 1));
          return COOKING_STEPS[Math.min(stepIdx + 1, COOKING_STEPS.length - 1)].duration;
        }
        return r - 1;
      });
    }, 1000);
    return () => clearInterval(id);
  }, [running, stepIdx]);

  const fmt = (s) => `${Math.floor(s/60)}:${String(s%60).padStart(2,"0")}`;
  const progress = ((step.duration - remaining) / step.duration) * 100;

  const toggleIng = (i) => setChecked(p => ({ ...p, [i]: !p[i] }));

  return (
    <section className="cooking" id="cooking">
      <div className="wrap">
        <div className="section-head">
          <div className="reveal">
            <div className="eyebrow" style={{ marginBottom: 18 }}><span className="eyebrow-dot" /> live demo · guided cooking</div>
            <h2>Cook it like you've <em>done it a hundred times.</em></h2>
          </div>
          <p className="lede reveal">
            One step at a time, with timers that run themselves and a little voice that's not your mom. Pause, rewind, ask why. Recipes you finish — and remember.
          </p>
        </div>

        <div className="cook-stage">
          <div className="cook-board reveal">
            <div className="cook-progress">
              {COOKING_STEPS.map((_, i) => (
                <div
                  key={i}
                  className={`cook-pip ${i < stepIdx ? "done" : i === stepIdx ? "now" : ""}`}
                  style={i === stepIdx ? { "--p": `${progress}%` } : {}}
                />
              ))}
            </div>

            <div className="cook-step-num">Step {step.id} of {COOKING_STEPS.length} · in progress</div>
            <h3 className="cook-step-title">{step.title}</h3>
            <p className="cook-step-detail">{step.detail}</p>

            <div className="cook-timer-box">
              <div>
                <div className="cook-timer-meta">timer remaining</div>
                <div className="cook-timer-clock">{fmt(remaining)}</div>
              </div>
              <div className="cook-controls">
                <button className="cook-ctrl" onClick={() => setStepIdx(Math.max(0, stepIdx - 1))} aria-label="Previous">‹</button>
                <button className="cook-ctrl" onClick={() => setRunning(r => !r)} aria-label={running ? "Pause" : "Play"}>{running ? "❚❚" : "▶"}</button>
                <button className="cook-ctrl" onClick={() => setStepIdx(Math.min(COOKING_STEPS.length - 1, stepIdx + 1))} aria-label="Next">›</button>
              </div>
            </div>

            <div className="cook-step-tabs">
              {COOKING_STEPS.map((s, i) => (
                <button
                  key={s.id}
                  className={`cook-tab ${i === stepIdx ? "active" : i < stepIdx ? "done" : ""}`}
                  onClick={() => setStepIdx(i)}
                >{i < stepIdx ? "✓ " : ""}{s.id} · {s.title.toLowerCase()}</button>
              ))}
            </div>
          </div>

          <div className="cook-ingredients reveal">
            <div className="rec-scribble" style={{ position: "absolute", top: -16, right: 18, transform: "rotate(4deg)", fontSize: 22 }}>
              tap to check off ↗
            </div>
            <h4>Mise en place</h4>
            <div className="ing-list">
              {INGREDIENTS.map((ing, i) => (
                <div
                  key={ing.name}
                  className={`ing-row ${checked[i] ? "checked" : ""}`}
                  onClick={() => toggleIng(i)}
                >
                  <span className="ing-check">{checked[i] ? "✓" : ""}</span>
                  <span>{ing.name}</span>
                  <span className="ing-amount">{ing.amt}</span>
                </div>
              ))}
            </div>
            <div style={{ marginTop: 22, padding: "14px 16px", background: "var(--paper)", borderRadius: 12, fontSize: 13, color: "var(--ink-soft)", borderLeft: "3px solid var(--matcha)" }}>
              <b style={{ fontFamily: "var(--mono)", fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "var(--matcha-deep)" }}>chef's note</b>
              <div style={{ marginTop: 6 }}>Quinoa is done when you see little spirals (the germ uncurling). Trust the spiral.</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

// ============================================================
// CTA + FOOTER
// ============================================================
function CTA() {
  const [email, setEmail] = useState("");
  const [submitted, setSubmitted] = useState(false);

  return (
    <section className="cta" id="cta">
      <div className="wrap">
        <div className="cta-box reveal">
          <h2 className="cta-headline">
            Stop guessing.<br />
            <em>Start craving smarter.</em>
          </h2>
          <p className="cta-sub">Free to start. No credit card. Your gut, your iron, your B12 — all on speaking terms.</p>
          <form className="cta-form" onSubmit={(e) => { e.preventDefault(); if (email) setSubmitted(true); }}>
            {submitted ? (
              <div style={{ fontFamily: "var(--serif)", fontStyle: "italic", fontSize: 28, color: "var(--ink)" }}>
                ✦ check your inbox — we sent your first match.
              </div>
            ) : (
              <>
                <input
                  type="email"
                  required
                  placeholder="you@email.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                />
                <button type="submit" className="btn btn-orange" style={{ boxShadow: "0 6px 0 var(--ink)" }}>Get my first meal →</button>
              </>
            )}
          </form>
          <p className="cta-fineprint">⌘ apple health · google fit · manual entry · all encrypted</p>
        </div>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="footer">
      <div className="wrap footer-inner">
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <span className="brand-mark" style={{ width: 28, height: 28, fontSize: 18 }}>m</span>
          <b style={{ fontWeight: 600 }}>MyFoodCraving</b>
        </div>
        <span className="label-mono">© 2026 · Infroid Technologies · cook well, live well</span>
      </div>
    </footer>
  );
}

window.Personalize = Personalize;
window.Cooking = Cooking;
window.CTA = CTA;
window.Footer = Footer;
