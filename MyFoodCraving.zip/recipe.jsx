// MyFoodCraving — Recipe page (data-driven, sample: Paneer Butter Masala)
const { useState, useEffect, useRef, useMemo, useCallback } = React;

// ============================================================
// SAMPLE RECIPE DATA (this whole UI is driven by this object)
// ============================================================
const RECIPE = {
  id: "paneer-butter-masala",
  name: "Paneer Butter Masala",
  tagline: "creamy · tomato · 35 min",
  cuisine: "North Indian",
  difficulty: "Easy",
  servings: 4,
  totalMinutes: 35,
  hero: {
    // placeholder swatch hint — CSS draws a stripe + warm wash
    palette: ["#FF6D2E", "#F4D67A", "#E2531A"],
    caption: "[ paneer butter masala — overhead shot ]"
  },
  // Health pointers shown on rotating marquee, surfaced every 3 min by default
  healthFacts: [
    "Paneer adds ~14g protein per 100g — a near-complete source for vegetarians.",
    "Cashews thicken the gravy without flour — adds magnesium + healthy fats.",
    "Tomatoes deliver lycopene, an antioxidant that's actually MORE bioavailable when cooked.",
    "Kasuri methi (dried fenugreek) is linked to better blood sugar response.",
    "Swap cream for cashew paste to keep richness while cutting saturated fat by ~40%.",
    "Ginger helps digestion — especially handy with rich, dairy-forward dishes."
  ],
  ingredients: [
    { name: "Paneer", amt: "300g", group: "main" },
    { name: "Tomatoes (ripe)", amt: "5 medium", group: "main" },
    { name: "Onion", amt: "1 large", group: "main" },
    { name: "Cashews", amt: "12–15 whole", group: "main" },
    { name: "Heavy cream", amt: "3 tbsp", group: "main" },
    { name: "Butter", amt: "3 tbsp", group: "fat" },
    { name: "Ginger-garlic paste", amt: "1.5 tbsp", group: "aromatics" },
    { name: "Green chili", amt: "1 (optional)", group: "aromatics" },
    { name: "Kasuri methi", amt: "1 tsp", group: "spice" },
    { name: "Garam masala", amt: "½ tsp", group: "spice" },
    { name: "Red chili powder", amt: "1 tsp (Kashmiri)", group: "spice" },
    { name: "Sugar", amt: "1 tsp", group: "spice" },
    { name: "Salt", amt: "to taste", group: "spice" }
  ],
  utensils: [
    { name: "Heavy-bottomed pan / kadhai", essential: true },
    { name: "Blender or mixie", essential: true },
    { name: "Fine strainer", essential: true },
    { name: "Wooden spatula", essential: false },
    { name: "Measuring spoons", essential: false },
    { name: "Small bowl for soaking cashews", essential: false }
  ],
  steps: [
    {
      id: 1,
      title: "Soak the cashews",
      detail: "Drop cashews in ½ cup hot water. Let them sit while you prep — they need to soften so the gravy stays silky, not gritty.",
      duration: 300, // 5 min, runs alongside next step
      tip: "Hot tap water works. Boiling = 5 min. Room temp = 30 min.",
      hasImage: true
    },
    {
      id: 2,
      title: "Sauté onion + tomato",
      detail: "Roughly chop onion and tomatoes. In 1 tbsp butter, sauté onion for 3 min until translucent, then add tomatoes, ginger-garlic paste, and chili. Cook 6–7 min until tomatoes break down completely.",
      duration: 600,
      tip: "Don't rush this. Tomatoes should look jammy and oil should separate slightly.",
      hasImage: true
    },
    {
      id: 3,
      title: "Blend the gravy base",
      detail: "Cool slightly, then blend the onion-tomato mix with the soaked cashews and ½ cup water until completely smooth. Pass through a fine strainer back into the pan — this is what makes restaurant-style silky.",
      duration: 240,
      tip: "Skip the strainer and you'll get a rustic, homestyle texture. Both are valid.",
      hasImage: false
    },
    {
      id: 4,
      title: "Bloom the spices",
      detail: "Add 2 tbsp butter to the pan. Once melted, add red chili powder and stir for 10 seconds — just long enough to bloom, not burn. Pour the strained gravy back in.",
      duration: 120,
      tip: "Kashmiri chili is mild + gives the signature red color without heat.",
      hasImage: false
    },
    {
      id: 5,
      title: "Simmer the gravy",
      detail: "Add salt, sugar, and ¼ cup water if needed. Simmer covered on low for 8 minutes, stirring once or twice. The gravy should glossy up and reduce slightly.",
      duration: 480,
      tip: "Sugar isn't for sweetness — it balances tomato acidity. Don't skip.",
      hasImage: true
    },
    {
      id: 6,
      title: "Add paneer + finish",
      detail: "Cube paneer (1-inch). Slip it into the gravy, add cream, garam masala, and crushed kasuri methi. Simmer 2 more minutes. Don't stir aggressively — paneer breaks easily.",
      duration: 180,
      tip: "Soak paneer cubes in warm water for 10 min beforehand for extra-soft texture.",
      hasImage: true
    },
    {
      id: 7,
      title: "Rest, then serve",
      detail: "Turn off the heat and let it sit covered for 5 minutes. The flavors marry in this window. Garnish with a swirl of cream and a pinch of methi. Serve with naan or jeera rice.",
      duration: 300,
      tip: "This rest step is what separates 'good' from 'great'. Try it.",
      hasImage: false
    }
  ]
};

window.RECIPE = RECIPE;
